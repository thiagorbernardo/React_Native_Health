=====================================
Pure Sugar - 60 Free SVG Icons (Freebie)
Crafted with Love by - NITISH Khagwal at Webkul HQ
===================================================================

The license hereby clearly declares that "Pure Sugar - 60 Free SVG Icons" is genuine and crafted by "Nitish Khagwal" at Webkul HQ. You are prohibited to sell or monetize "Pure Sugar - 60 Free SVG Icons" as an individual product under any circumstances. 
You are all free to use "Pure Sugar - 60 Free SVG Icons" in any of your personal or commercial projects partially without any formal attribution. Each asset can be used without any restriction to copy, modify, merge, publish and/or sell copies of the software or apps produced.

© Copyright Webkul Software

...................................
...................................
